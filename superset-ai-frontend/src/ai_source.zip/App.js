import React, { useState, useEffect, useRef } from "react";
import { Send, Loader2, History, X } from "lucide-react";

export default function SmartAI() {
  const [question, setQuestion] = useState("");
  const [conversation, setConversation] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [welcomeText, setWelcomeText] = useState("");
  const [queryHistory, setQueryHistory] = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const chatEndRef = useRef(null);

  const welcomeMessage = "Hi, I'm your AI Data Assistant. Ask me anything about your data.";

  // Welcome message typing animation
  useEffect(() => {
    if (!showWelcome) return;

    let currentIndex = 0;
    const typeText = () => {
      if (currentIndex <= welcomeMessage.length) {
        setWelcomeText(welcomeMessage.substring(0, currentIndex));
        currentIndex++;
        setTimeout(typeText, 100);
      } else {
        setTimeout(() => {
          setShowWelcome(false);
        }, 1000);
      }
    };

    typeText();
  }, [showWelcome]);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation, loading]);

  // Format response to clean numbering
  const formatResponse = (text) => {
    // Remove **bold** markdown and clean up numbering
    return text
      .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold markers
      .replace(/(\d+)\.\s*\*\*/g, '$1. ') // Clean numbered lists with bold
      .replace(/\*\*(\d+)\./g, '$1.') // Fix bold numbering
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .join('\n');
  };

  const ask = async () => {
    if (!question.trim()) return;

    const userQuestion = question;
    setQuestion("");
    setLoading(true);

    // Add user question to conversation
    const newConversation = [...conversation, { type: "user", content: userQuestion }];
    setConversation(newConversation);

    try {
      const res = await fetch("http://localhost:5000/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ question: userQuestion })
      });

      const data = await res.json();
      const formattedAnswer = formatResponse(data.answer || "No response.");
      
      // Add AI response to conversation
      setConversation(prev => [...prev, { 
        type: "ai", 
        content: formattedAnswer,
        rawQuestion: userQuestion
      }]);

      // Add to query history if it's a new unique query
      setQueryHistory(prev => {
        const existing = prev.find(item => item.question === userQuestion);
        if (!existing) {
          return [{ 
            question: userQuestion, 
            answer: formattedAnswer,
            timestamp: new Date().toLocaleTimeString()
          }, ...prev];
        }
        return prev;
      });

    } catch (err) {
      const errorMsg = "Error connecting to AI service.";
      setConversation(prev => [...prev, { 
        type: "ai", 
        content: errorMsg 
      }]);
    }

    setLoading(false);
  };

  const loadHistoryItem = (historyItem) => {
    // Clear current conversation and show only this history item
    setConversation([
      { type: "user", content: historyItem.question },
      { type: "ai", content: historyItem.answer }
    ]);
  };

  return (
    <div className="flex h-screen bg-slate-900">
      {/* Sidebar - Query History */}
      {sidebarOpen && (
        <div className="w-80 bg-slate-800 border-r border-slate-700 flex flex-col">
          <div className="p-4 border-b border-slate-700">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">Query History</h2>
              <button 
                onClick={() => setSidebarOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2">
            {queryHistory.length === 0 ? (
              <div className="text-slate-400 text-center p-4">
                No queries yet. Ask something!
              </div>
            ) : (
              queryHistory.map((item, index) => (
                <div
                  key={index}
                  onClick={() => loadHistoryItem(item)}
                  className="p-3 mb-2 bg-slate-700 rounded-lg cursor-pointer hover:bg-slate-600 transition-colors"
                >
                  <div className="text-white text-sm font-medium truncate">
                    {item.question}
                  </div>
                  <div className="text-slate-400 text-xs mt-1">
                    {item.timestamp}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-slate-800 p-4 border-b border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {!sidebarOpen && (
                <button 
                  onClick={() => setSidebarOpen(true)}
                  className="text-slate-400 hover:text-white p-2"
                >
                  <History className="w-5 h-5" />
                </button>
              )}
              <h1 className="text-xl font-bold text-white">
                Smart Applications AI Assistant
              </h1>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Welcome Message */}
          {showWelcome && (
            <div className="flex justify-center">
              <div className="bg-blue-600 text-white p-6 rounded-lg max-w-3xl">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center mr-4">
                    <span className="text-blue-600 text-sm font-bold">AI</span>
                  </div>
                  <div className="text-lg">
                    {welcomeText}
                    <span className="ml-1 animate-pulse">|</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Conversation History */}
          {conversation.map((msg, index) => (
            <div
              key={index}
              className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-3xl p-6 rounded-2xl ${
                  msg.type === "user" 
                    ? "bg-blue-600 text-white" 
                    : "bg-slate-700 text-slate-200"
                }`}
              >
                {msg.type === "ai" && (
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3">
                      <span className="text-white text-sm font-bold">AI</span>
                    </div>
                    <span className="text-blue-300 font-medium">Assistant</span>
                  </div>
                )}
                <div className="whitespace-pre-wrap">
                  {msg.content}
                </div>
              </div>
            </div>
          ))}

          {/* Loading Indicator */}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-slate-700 text-slate-200 p-6 rounded-2xl max-w-3xl">
                <div className="flex items-center">
                  <Loader2 className="w-6 h-6 animate-spin mr-3" />
                  <span className="text-lg">Thinking...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Input Area */}
        <div className="bg-slate-800 p-6 border-t border-slate-700">
          <div className="max-w-5xl mx-auto flex gap-4">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && ask()}
              placeholder="Ask a question about your data..."
              className="flex-1 px-6 py-4 rounded-xl bg-slate-700 text-white text-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={ask}
              disabled={loading || !question.trim()}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white px-8 py-4 rounded-xl flex items-center gap-3 text-lg"
            >
              {loading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <Send className="w-6 h-6" />
              )}
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
